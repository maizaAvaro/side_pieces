
Prior to running an instance of the program, the Helper.class must be located in the source
directory.

Compile the program by typing make compile
Run the program by typing make run
Clean the class files by typing make clean
	clean will wipe Helper.class as well, so it must be copied back into the source directory

Keyboard Shortcuts:


Alt+F - Open File Menu
Alt+S - Open Settings Menu
Alt+H - Open Help Menu

q - Quit Program
s - Set Current Class File
t - Open Quick Tips File
a - Open About File


To begin Attendance Tracker, first click on browse class files or choose
set current class from the menu. After the roster has been reviewed, 
click on browse scan files to add attendance scans for specific class
days. An updated roster file with students present represented with a 1
and students absent represented with a 0 will pop up. Once this has been
reviewed to satisfaction, click on the generate stats button to view a
bar graph that will display the average attendance ratio represented by a
green bar. 