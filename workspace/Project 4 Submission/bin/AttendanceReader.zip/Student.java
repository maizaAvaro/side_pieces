
public class Student {
	public Student(String id, String attendance){
		
	}
}

